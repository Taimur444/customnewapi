<?php

namespace Drupal\custom_newapi\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;

use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
use Drupal\taxonomy\Entity\Term;
use Drupal\file\Entity\File;

/**
 * Class CustomNewapiContentPage.
 */
class CustomNewapiContentPageupdateactrole extends ControllerBase { // class start

  public function genrate( Request $request ) {  // function for json decode 

        $data3 = json_decode( $request->getContent(), TRUE ); // store value of json decode in variable
        $count = 0;
        foreach($data3 as $json_node_data2){  // foreach for json data

           $nid = isset($json_node_data2['nid']) ? $json_node_data2['nid'] : "" ; 
    	     $actor_ids = isset($json_node_data2['actor_ids']) ? $json_node_data2['actor_ids'] : "" ;
           $unique_id = isset($json_node_data2['unique_id']) ? $json_node_data2['unique_id'] : "" ;
           $last_updated_date = isset($json_node_data2['last_updated_date']) ? $json_node_data2['last_updated_date'] : "" ;
          $role_color = isset($json_node_data2['role_color']) ? $json_node_data2['role_color'] : "" ;
          $role_symbol = isset($json_node_data2['role_symbol']) ? $json_node_data2['role_symbol'] : "" ;
          $role_play_unique_id = isset($json_node_data2['role_play_unique_id']) ? $json_node_data2['role_play_unique_id'] : "" ;
          $role_layer_unique_id = isset($json_node_data2['role_layer_unique_id']) ? $json_node_data2['role_layer_unique_id'] : "" ;
          $role_order = isset($json_node_data2['role_order']) ? $json_node_data2['role_order'] : "" ;
   
    
          $node_storage_act_role = \Drupal::entityManager()->getStorage('node');
          $load_nodeid_act_role = $node_storage_act_role->load($nid);
		  // $role_pages_title = $load_node_role_pages->getTitle();//get field
         
          $load_nodeid_act_role->set('field_actor_ids', $actor_ids);
          $load_nodeid_act_role->set('field_unique_id', $unique_id);
          $load_nodeid_act_role->set('field_last_updated_date', $last_updated_date);
          $load_nodeid_act_role->set('field_role_color', $role_color);
          $load_nodeid_act_role->set('field_role_symbol', $role_symbol);
          $load_nodeid_act_role->set('field_role_play_unique_id', $role_play_unique_id);
          $load_nodeid_act_role->set('field_role_layer_unique_id', $role_layer_unique_id);
          $load_nodeid_act_role->set('field_role_order', $role_order);

         
		  

          $load_nodeid_act_role->save();

          $response['data'][$count]['nid'] =  $nid;
          $response['data'][$count]['actor_ids'] =$actor_ids;
          $response['data'][$count]['unique_id'] =$unique_id;
          $response['data'][$count]['last_updated_date'] =$last_updated_date;
          $response['data'][$count]['role_color'] =$role_color;
          $response['data'][$count]['role_symbol'] =$role_symbol;
          $response['data'][$count]['role_play_unique_id'] =$role_play_unique_id;
          $response['data'][$count]['role_layer_unique_id'] =$role_layer_unique_id;
          $response['data'][$count]['role_order'] =$role_order;
          $count = $count + 1;
        } //for each loop end
         
         return new JsonResponse( $response );
         
        
   } // function end


   
}/// END CLASS ///
